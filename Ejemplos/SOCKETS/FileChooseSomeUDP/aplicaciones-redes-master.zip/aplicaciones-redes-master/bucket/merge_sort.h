#ifndef __MERGE_SORT__
#define __MERGE_SORT__

void merge_sort(int *, int, int);
void merge(int *, int, int, int);
#endif