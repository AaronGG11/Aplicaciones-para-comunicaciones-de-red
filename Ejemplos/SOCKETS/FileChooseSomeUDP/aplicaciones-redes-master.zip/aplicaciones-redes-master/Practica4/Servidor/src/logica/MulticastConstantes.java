package logica;

public interface MulticastConstantes {
    String DIRECCION = "235.1.1.1";
    int PUERTO = 4445;
    int TAM_BUFFER = 6400;
}
