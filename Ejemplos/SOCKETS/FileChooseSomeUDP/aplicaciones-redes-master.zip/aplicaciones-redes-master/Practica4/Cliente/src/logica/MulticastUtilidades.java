package logica;

public interface MulticastUtilidades {
    String DIRECCION = "235.1.1.1";
    int PUERTO = 4445;
    int TAM_BUFFER = 8000;
}
